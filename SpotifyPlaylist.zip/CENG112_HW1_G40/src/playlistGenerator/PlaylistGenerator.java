package playlistGenerator;

import java.security.KeyStore;
import java.util.Arrays;
import java.util.HashMap;

public class PlaylistGenerator
{
    HashMap<Integer, Bag<Song>> songs;
    HashMap<Integer, Bag<Song>> playlist;
    int numberOfPlaylists = 0;
    int [] minimumDurations = {2700 , 3600, 5400, 7200, 10800};
    int [][] genresForPlaylists = {{2, 1, 5}, {4, 3, 6}, {5,1,2}, {2,1,5}, {3, 6, 1}};

    public PlaylistGenerator(HashMap<Integer, Bag<Song>> songs){
        this.songs = songs;
        this.playlist =  new HashMap<Integer, Bag<Song>>();
    }

    public void createPlayList( int typeOfPlaylist){
        Bag<Song>  newList = new Bag<Song>(1);
        this.playlist.put(numberOfPlaylists + 1, newList);
        this.numberOfPlaylists++;
        int minDuration = this.minimumDurations[typeOfPlaylist -1];
        int[] genres = this.genresForPlaylists[typeOfPlaylist -1];
        int duration = 0;
        boolean first, second, third = false;
        Song songFirst, songSecond, songThird;
        int noOfSong = 0;
        Song [] temp = new Song[3];
        Song [] songsThisRound;
        while (duration < minDuration){

            if (songs.get(genres[0]).getElements().length !=0 ){
                songFirst = (Song) songs.get(genres[0]).getElements()[0];
                temp[0] = songFirst;
                noOfSong++;
            }
            if (songs.get(genres[1]).getElements().length !=0 ){
                songSecond = (Song) songs.get(genres[1]).getElements()[0];
                temp[1] = songSecond;
                noOfSong++;
            }
            if (songs.get(genres[2]).getElements().length !=0 ){
                songThird = (Song) songs.get(genres[2]).getElements()[0];
                temp[2] = songThird;
                noOfSong++;
            }
            songsThisRound = new Song[noOfSong];
            int currentIndex = 0;
            for ( int i =0; i < noOfSong; i++) {
                if (temp[i] != null){
                    songsThisRound[currentIndex] =  temp[i];
                    currentIndex++;
                }
            }

            Arrays.sort(songsThisRound);
            this.playlist.get(numberOfPlaylists).add(songsThisRound[0]);
            this.songs.get(songsThisRound[0].getGenreId()).remove();
            duration += songsThisRound[0].getTrackDuration();
            noOfSong = 0;

        }

    }

    public int[] getResults() {
        Bag<Song> list = this.playlist.get(this.numberOfPlaylists);
        int noOfTracks = list.getSize();
        int totalDuration = 0;
        int avgPopularity = 0;
        Song song;
        for (int i=0; i < noOfTracks; i++) {
            song = (Song) list.getElements()[0];
            totalDuration +=  song.getTrackDuration();
            avgPopularity +=  song.getTrackPopularity();
        }
        avgPopularity /= list.getSize();
        totalDuration /= 60; // display in minutes
        return new int[]{noOfTracks, totalDuration, avgPopularity};
    }

}
