package playlistGenerator;

import java.util.Scanner;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        boolean done = false;
        while(!done) {
    	    DataParser dataParser = new DataParser("src/playlistGenerator/tracks.txt");
            dataParser.parseTracks();
            PlaylistGenerator playlistGenerator = new PlaylistGenerator(dataParser.getGenres());
            System.out.println("[1] Sleeping \n" +
                    "[2] Workout\n" +
                    "[3] Dining\n" +
                    "[4] Meditation\n" +
                    "[5] Road Trip");
            Scanner myObj = new Scanner(System.in);
            System.out.println("Enter type");
            int type = myObj.nextInt();
            switch (type) {
                case 0 -> done = true;
                case 1 -> playlistGenerator.createPlayList(1);
                case 2 -> playlistGenerator.createPlayList(2);
                case 3 -> playlistGenerator.createPlayList(3);
                case 4 -> playlistGenerator.createPlayList(4);
                case 5 -> playlistGenerator.createPlayList(5);
            }
            int[] results = playlistGenerator.getResults();
            System.out.println("Number of tracks : " + results[0]);
            System.out.println("Total duration : " + results[1]);
            System.out.println("Average Popularity : " + results[2]);

        }
    }
}