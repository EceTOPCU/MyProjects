package playlistGenerator;

public class Song implements Comparable<Song> {
    private int genreId;
    private int trackId;
    private int trackDuration;
    private int trackPopularity;
    public Song (int genreId, int trackId, int trackDuration, int trackPopularity) {
        this.genreId = genreId;
        this.trackId = trackId;
        this.trackDuration = trackDuration;
        this.trackPopularity = trackPopularity;
    }

    public int getGenreId() {
        return genreId;
    }

    public void setGenreId(int genreId) {
        this.genreId = genreId;
    }

    public int getTrackId() {
        return trackId;
    }

    public void setTrackId(int trackId) {
        this.trackId = trackId;
    }

    public int getTrackDuration() {
        return trackDuration;
    }

    public void setTrackDuration(int trackDuration) {
        this.trackDuration = trackDuration;
    }

    public int getTrackPopularity() {
        return trackPopularity;
    }

    public void setTrackPopularity(int trackPopularity) {
        this.trackPopularity = trackPopularity;
    }

    @Override
    public int compareTo(Song o) {
        return this.trackPopularity - o.trackPopularity;
    }
}
