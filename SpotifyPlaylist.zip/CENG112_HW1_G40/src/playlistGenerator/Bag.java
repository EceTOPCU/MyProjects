package playlistGenerator;

import java.util.Arrays;

public class Bag<Song> implements ArrayBag<Song>{

    private Song[] elements;
    private int size;

    public Bag(int capacity){
        this.elements = (Song[]) new Object[capacity];
        this.size = 0;
    }
    @Override
    public void add(Song element) {
        if (this.size < elements.length)
        { elements[this.size] = element;
            this.size++;

        }
        else
        {
            Song[] temp = (Song[]) new Object[this.elements.length + 1];
            System.arraycopy(this.elements, 0, temp, 0, this.elements.length);
            this.elements = temp;
            temp[size] = element;
            Arrays.sort(this.elements);
            this.size++;

        }
    }

    @Override
    public void remove() {
        int i = 0;
        Song[] temp = (Song[]) new Object[this.elements.length - 1];
        for ( int j = 1; j < this.elements.length; j++){
            temp[i] = this.elements[j];
            i++;
        }
        this.elements = temp;
        this.size--;
    }


    @Override
    public int size() {
        return this.size;
    }


    public Object[] getElements() {
        return elements;
    }

    public void setElements(Song[] elements) {
        this.elements = elements;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }


}
