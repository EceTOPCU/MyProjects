package playlistGenerator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

public class DataParser {
    private String fname;
    private HashMap<Integer, Bag<Song>> genres  = new HashMap<Integer, Bag<Song>>();
    public DataParser(String fname) {
        this.fname = fname;
        this.createGenreBags();
    }

    public void parseTracks() throws IOException {
        FileReader input = new FileReader(this.fname);
        BufferedReader bufRead = new BufferedReader(input);
        String trackLine = null;
        while ( (trackLine = bufRead.readLine()) != null)
        {
            String [] track = trackLine.split(",");
            this.genres.get(Integer.parseInt(track[0])).add(new Song(Integer.parseInt(track[0]),
                    Integer.parseInt(track[1]),Integer.parseInt(track[2]),Integer.parseInt(track[3])));
        }
    }

    public void createGenreBags(){
        for (int i= 1; i<7; i++){
            Bag<Song> new_bag = new Bag<Song>(1);
            this.genres.put(i, new_bag);
        }
    }
    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public HashMap<Integer, Bag<Song>> getGenres() {
        return genres;
    }

    public void setGenres(HashMap<Integer, Bag<Song>> genres) {
        this.genres = genres;
    }
}
