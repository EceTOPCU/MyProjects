package playlistGenerator;
public interface ArrayBag<Song> {

    int size = 0;

    void add(Song song);
    void remove();
    int size();

}